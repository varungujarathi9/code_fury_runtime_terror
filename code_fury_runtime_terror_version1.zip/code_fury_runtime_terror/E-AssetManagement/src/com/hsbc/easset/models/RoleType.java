package com.hsbc.easset.models;

public enum RoleType {
ADMIN,BORROWER
}
