package com.hsbc.easset.exceptions;

public class DuplicateEmailIdException extends Exception{
	
	public DuplicateEmailIdException(String message)
	{
		super(message);
	}

}
