package com.hsbc.easset.exceptions;

public class DBConnCreationException extends Exception{

	public DBConnCreationException(String message)
	{
		super(message);
	}
}
