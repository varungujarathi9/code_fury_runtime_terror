package com.hsbc.easset.exceptions;

public class PasswordMismatchException extends Exception{
	
	public PasswordMismatchException(String message)
	{
		super(message);
	}

}
